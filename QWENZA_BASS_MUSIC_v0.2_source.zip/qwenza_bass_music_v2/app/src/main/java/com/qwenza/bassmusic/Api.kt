package com.qwenza.bassmusic

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

// Emulator: 10.0.2.2 is the host computer. Replace with your deployed HTTPS URL.
const val API_BASE_URL = "http://10.0.2.2:8080/"

data class AuthRequest(val email: String, val password: String, val displayName: String? = null)
data class AuthResponse(val token: String, val user: UserDto)
data class UserDto(val id: String, val email: String, val displayName: String)
data class TrackDto(
    val id: String,
    val title: String,
    val artist: String,
    val coverUrl: String? = null,
    val streamUrl: String
)

interface QwenzaApi {
    @POST("auth/register") suspend fun register(@Body body: AuthRequest): AuthResponse
    @POST("auth/login") suspend fun login(@Body body: AuthRequest): AuthResponse
    @GET("me") suspend fun me(@Header("Authorization") bearer: String): UserDto
    @GET("tracks") suspend fun tracks(@Header("Authorization") bearer: String): List<TrackDto>
}

object ApiClient {
    val api: QwenzaApi by lazy {
        Retrofit.Builder()
            .baseUrl(API_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(QwenzaApi::class.java)
    }
}
