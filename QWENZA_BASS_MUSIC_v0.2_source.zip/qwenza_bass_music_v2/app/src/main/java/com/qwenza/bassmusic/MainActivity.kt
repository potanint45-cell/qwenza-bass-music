package com.qwenza.bassmusic

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

private val Black = Color(0xFF080808)
private val SurfaceDark = Color(0xFF171717)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFF9B9B9B)

private enum class AppTab { HOME, SEARCH, LIBRARY, PROFILE, SETTINGS }
private enum class ThemeChoice { DARK, LIGHT, SYSTEM }

class MainActivity : ComponentActivity() {
    private var exoPlayer: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        exoPlayer = ExoPlayer.Builder(this).build()
        setContent {
            QwenzaRoot(
                context = this,
                player = exoPlayer!!,
                onReleasePlayer = { exoPlayer?.release(); exoPlayer = null }
            )
        }
    }

    override fun onDestroy() {
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }
}

@Composable
private fun QwenzaRoot(context: Context, player: ExoPlayer, onReleasePlayer: () -> Unit) {
    val prefs = remember { context.getSharedPreferences("qwenza_settings", Context.MODE_PRIVATE) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "DARK") ?: "DARK") }
    var accent by remember { mutableStateOf(prefs.getString("accent", "WHITE") ?: "WHITE") }
    var wallpaper by remember { mutableStateOf(prefs.getString("wallpaper", null)) }
    var playerWallpaper by remember { mutableStateOf(prefs.getString("player_wallpaper", null)) }
    var opacity by remember { mutableFloatStateOf(prefs.getFloat("opacity", 0.92f)) }
    val isLight = theme == "LIGHT"
    val bg = if (isLight) Color(0xFFF4F4F4) else Black
    val fg = if (isLight) Color(0xFF111111) else White
    val panel = if (isLight) Color(0xFFE5E5E5) else SurfaceDark
    val accentColor = when (accent) {
        "SILVER" -> Color(0xFFBFC3C8)
        "GRAPHITE" -> Color(0xFF777777)
        "ICE" -> Color(0xFFB8E7F2)
        "PURPLE" -> Color(0xFFB69AFF)
        else -> if (isLight) Color(0xFF111111) else White
    }
    var tab by remember { mutableStateOf(AppTab.HOME) }
    var token by remember { mutableStateOf(prefs.getString("token", null)) }
    var user by remember { mutableStateOf<UserDto?>(null) }
    var tracks by remember { mutableStateOf<List<TrackDto>>(emptyList()) }
    var current by remember { mutableStateOf<TrackDto?>(null) }
    var playing by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Твой музыкальный мир") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var registerMode by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            wallpaper = it.toString()
            prefs.edit().putString("wallpaper", wallpaper).apply()
        }
    }
    val playerWallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            playerWallpaper = it.toString()
            prefs.edit().putString("player_wallpaper", playerWallpaper).apply()
        }
    }

    fun play(track: TrackDto) {
        current = track
        player.setMediaItem(MediaItem.fromUri(track.streamUrl))
        player.prepare()
        player.play()
        playing = true
    }

    fun loadAccount(authToken: String) {
        scope.launch {
            try {
                val auth = "Bearer $authToken"
                user = ApiClient.api.me(auth)
                tracks = ApiClient.api.tracks(auth)
                status = "Музыка загружена"
            } catch (_: Exception) {
                status = "Сервер недоступен — проверь адрес API"
            }
        }
    }

    LaunchedEffect(token) { token?.let { loadAccount(it) } }

    MaterialTheme(colorScheme = if (isLight) lightColorScheme(
        primary = accentColor, background = bg, surface = panel, onBackground = fg, onSurface = fg
    ) else darkColorScheme(
        primary = accentColor, background = bg, surface = panel, onBackground = fg, onSurface = fg
    )) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            if (token.isNullOrBlank()) {
                AuthScreen(
                    fg, panel, accentColor, email, { email = it }, password, { password = it },
                    displayName, { displayName = it }, registerMode, { registerMode = it }, status
                ) {
                    scope.launch {
                        try {
                            val result = if (registerMode)
                                ApiClient.api.register(AuthRequest(email, password, displayName))
                            else ApiClient.api.login(AuthRequest(email, password))
                            token = result.token
                            user = result.user
                            prefs.edit().putString("token", result.token).apply()
                            loadAccount(result.token)
                        } catch (_: Exception) {
                            status = "Не удалось войти. Проверь сервер и данные."
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    when (tab) {
                        AppTab.HOME -> HomeScreen(fg, panel, accentColor, wallpaper, tracks, current, playing, { play(it) }, { tab = AppTab.SEARCH })
                        AppTab.SEARCH -> SearchScreen(fg, panel, tracks, search, { search = it }, { play(it) })
                        AppTab.LIBRARY -> LibraryScreen(fg, panel, tracks, { play(it) })
                        AppTab.PROFILE -> ProfileScreen(fg, panel, user, tracks.size, current)
                        AppTab.SETTINGS -> SettingsScreen(
                            fg, panel, accentColor, theme, { theme = it; prefs.edit().putString("theme", it).apply() },
                            accent, { accent = it; prefs.edit().putString("accent", it).apply() },
                            opacity, { opacity = it; prefs.edit().putFloat("opacity", it).apply() },
                            wallpaper, { wallpaperPicker.launch(arrayOf("image/*")) },
                            playerWallpaper, { playerWallpaperPicker.launch(arrayOf("image/*")) },
                            { wallpaper = null; playerWallpaper = null; theme = "DARK"; accent = "WHITE"; opacity = 0.92f
                              prefs.edit().remove("wallpaper").remove("player_wallpaper").putString("theme", "DARK")
                                  .putString("accent", "WHITE").putFloat("opacity", 0.92f).apply() }
                        )
                    }
                    current?.let { MiniPlayer(fg, panel, it, playing, {
                        if (player.isPlaying) { player.pause(); playing = false }
                        else { player.play(); playing = true }
                    }) }
                    NavigationBar(tab, fg, panel, accentColor) { tab = it }
                }
            }
        }
    }
}

@Composable
private fun AuthScreen(
    fg: Color, panel: Color, accent: Color, email: String, onEmail: (String) -> Unit,
    password: String, onPassword: (String) -> Unit, name: String, onName: (String) -> Unit,
    register: Boolean, onRegister: (Boolean) -> Unit, status: String, onSubmit: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Q", color = fg, fontSize = 68.sp, fontWeight = FontWeight.Black)
        Text("QWENZA", color = fg, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Text("B A S S   M U S I C", color = accent, fontSize = 12.sp)
        Spacer(Modifier.height(28.dp))
        Text(if (register) "Создать аккаунт" else "С возвращением", color = fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (register) Field(name, onName, "Имя", fg, panel)
        Field(email, onEmail, "Электронная почта", fg, panel)
        Field(password, onPassword, "Пароль", fg, panel)
        Button(onClick = onSubmit, modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)) {
            Text(if (register) "Зарегистрироваться" else "Войти")
        }
        TextButton(onClick = { onRegister(!register) }) {
            Text(if (register) "Уже есть аккаунт? Войти" else "Создать аккаунт", color = fg)
        }
        Text(status, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, label: String, fg: Color, panel: Color) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        singleLine = true, colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = fg, unfocusedTextColor = fg,
            focusedContainerColor = panel, unfocusedContainerColor = panel
        ))
}

@Composable
private fun HomeScreen(
    fg: Color, panel: Color, accent: Color, wallpaper: String?, tracks: List<TrackDto>,
    current: TrackDto?, playing: Boolean, onPlay: (TrackDto) -> Unit, onSearch: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("QWENZA", color = fg, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("BASS MUSIC", color = accent, fontSize = 10.sp, letterSpacing = 4.sp)
            }
            Icon(Icons.Default.Search, contentDescription = "Поиск", tint = fg, modifier = Modifier.size(26.dp).clickable { onSearch() })
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().height(174.dp)) {
            if (wallpaper != null) AsyncImage(wallpaper, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxSize().background(panel, RoundedCornerShape(22.dp)))
            Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                Text("ТВОЯ МУЗЫКА", color = fg, fontSize = 11.sp, letterSpacing = 3.sp)
                Text("Слушай. Настраивай. Наслаждайся.", color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("РЕКОМЕНДАЦИИ", color = fg, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        if (tracks.isEmpty()) {
            Text("Треки появятся здесь после подключения музыкального сервера.", color = Muted, modifier = Modifier.padding(vertical = 18.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tracks) { track -> TrackRow(track, fg, panel, accent) { onPlay(track) } }
            }
        }
    }
}

@Composable
private fun SearchScreen(fg: Color, panel: Color, tracks: List<TrackDto>, search: String, onSearch: (String) -> Unit, onPlay: (TrackDto) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Поиск", color = fg, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(search, onSearch, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            placeholder = { Text("Название или исполнитель") }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tracks.filter { it.title.contains(search, true) || it.artist.contains(search, true) }) {
                TrackRow(it, fg, panel, fg) { onPlay(it) }
            }
        }
    }
}

@Composable
private fun LibraryScreen(fg: Color, panel: Color, tracks: List<TrackDto>, onPlay: (TrackDto) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Медиатека", color = fg, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("${tracks.size} треков в каталоге", color = Muted)
        LazyColumn { items(tracks) { TrackRow(it, fg, panel, fg) { onPlay(it) } } }
    }
}

@Composable
private fun TrackRow(track: TrackDto, fg: Color, panel: Color, accent: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Color(0xFF333333), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.GraphicEq, null, tint = accent)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(track.title, color = fg, fontWeight = FontWeight.SemiBold)
            Text(track.artist, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.PlayArrow, null, tint = fg)
    }
}

@Composable
private fun MiniPlayer(fg: Color, panel: Color, track: TrackDto, playing: Boolean, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(panel).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(track.title, color = fg, fontWeight = FontWeight.Bold)
            Text(track.artist, color = Muted, fontSize = 12.sp)
        }
        IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = fg) }
    }
}

@Composable
private fun ProfileScreen(fg: Color, panel: Color, user: UserDto?, trackCount: Int, current: TrackDto?) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Box(Modifier.size(92.dp).background(panel, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
            Text("Q", color = fg, fontSize = 52.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(14.dp))
        Text(user?.displayName ?: "QWENZA USER", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(user?.email ?: "", color = Muted)
        Spacer(Modifier.height(24.dp))
        Text("$trackCount треков в каталоге", color = fg)
        Text("Сейчас играет: ${current?.title ?: "ничего"}", color = Muted)
    }
}

@Composable
private fun SettingsScreen(
    fg: Color, panel: Color, accentColor: Color,
    theme: String, setTheme: (String) -> Unit, accent: String, setAccent: (String) -> Unit,
    opacity: Float, setOpacity: (Float) -> Unit, wallpaper: String?, chooseWallpaper: () -> Unit,
    playerWallpaper: String?, choosePlayerWallpaper: () -> Unit, reset: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text("Настройки", color = fg, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
            Text("ПЕРСОНАЛИЗАЦИЯ", color = accentColor, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("Тема приложения", color = fg, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
                ThemeChip("Тёмная", theme == "DARK", fg, panel) { setTheme("DARK") }
                ThemeChip("Светлая", theme == "LIGHT", fg, panel) { setTheme("LIGHT") }
                ThemeChip("Системная", theme == "SYSTEM", fg, panel) { setTheme("SYSTEM") }
            }
            Text("Цвет акцентов", color = fg, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                listOf("WHITE", "SILVER", "GRAPHITE", "ICE", "PURPLE").forEach { choice ->
                    val c = when (choice) {
                        "SILVER" -> Color(0xFFBFC3C8)
                        "GRAPHITE" -> Color(0xFF777777)
                        "ICE" -> Color(0xFFB8E7F2)
                        "PURPLE" -> Color(0xFFB69AFF)
                        else -> Color.White
                    }
                    Box(Modifier.size(32.dp).background(c, RoundedCornerShape(50))
                        .clickable { setAccent(choice) }
                        .padding(3.dp), contentAlignment = Alignment.Center) {
                        if (accent == choice) Icon(Icons.Default.Check, null, tint = Color.Black, modifier = Modifier.size(17.dp))
                    }
                }
            }
            Divider(color = panel)
            SettingAction("Обои приложения", if (wallpaper == null) "Выбрать готовые или из галереи" else "Свой фон установлен", fg, chooseWallpaper)
            SettingAction("Обои плеера", if (playerWallpaper == null) "Отдельный фон экрана плеера" else "Свой фон установлен", fg, choosePlayerWallpaper)
            Text("Прозрачность интерфейса: ${(opacity * 100).toInt()}%", color = fg, modifier = Modifier.padding(top = 10.dp))
            Slider(value = opacity, onValueChange = setOpacity, valueRange = 0.35f..1f)
            Spacer(Modifier.height(14.dp))
            Button(onClick = reset, colors = ButtonDefaults.buttonColors(containerColor = panel, contentColor = fg),
                modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.RestartAlt, null)
                Spacer(Modifier.width(8.dp))
                Text("Сбросить оформление")
            }
            Spacer(Modifier.height(16.dp))
            Text("АККАУНТ И СЕРВЕР", color = accentColor, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Адрес API настраивается в Api.kt. Для публикации используй HTTPS.", color = Muted, fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp, bottom = 30.dp))
        }
    }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, fg: Color, panel: Color, onClick: () -> Unit) {
    Surface(color = if (selected) fg else panel, shape = RoundedCornerShape(30.dp), modifier = Modifier.clickable { onClick() }) {
        Text(label, color = if (selected) Color.Black else fg, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp), fontSize = 12.sp)
    }
}

@Composable
private fun SettingAction(title: String, subtitle: String, fg: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = fg, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = fg)
    }
    Divider(color = Color(0xFF303030))
}

@Composable
private fun NavigationBar(tab: AppTab, fg: Color, panel: Color, accent: Color, onSelect: (AppTab) -> Unit) {
    Row(Modifier.fillMaxWidth().background(panel).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf(
            AppTab.HOME to (Icons.Default.Home to "Главная"),
            AppTab.SEARCH to (Icons.Default.Search to "Поиск"),
            AppTab.LIBRARY to (Icons.Default.LibraryMusic to "Медиатека"),
            AppTab.PROFILE to (Icons.Default.Person to "Профиль"),
            AppTab.SETTINGS to (Icons.Default.Settings to "Настройки")
        ).forEach { (item, pair) ->
            Column(Modifier.clickable { onSelect(item) }.padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(pair.first, null, tint = if (tab == item) accent else Muted)
                Text(pair.second, color = if (tab == item) fg else Muted, fontSize = 9.sp)
            }
        }
    }
}
