# QWENZA BASS MUSIC API

Минимальный backend для регистрации, входа, профиля и каталога треков.

## Запуск
1. Установи Node.js и PostgreSQL.
2. Создай базу `qwenza` и пользователя БД.
3. Скопируй `.env.example` в `.env`, задай `DATABASE_URL` и длинный случайный `JWT_SECRET`.
4. `npm install`
5. `npm start`
6. Положи аудиофайлы в папку `media/`.

Добавление треков в таблицу `tracks`:
```sql
INSERT INTO tracks(title, artist, file_name, cover_url)
VALUES ('Bass Demo', 'Qwenza', 'bass-demo.mp3', NULL);
```

Перед реальным запуском в интернете настрой HTTPS, ограничения CORS, rate limiting,
резервные копии БД, модерацию/права на аудио и безопасную загрузку файлов.
Не выставляй PostgreSQL наружу без сетевых ограничений.
