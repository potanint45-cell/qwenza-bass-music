require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Pool } = require("pg");
const path = require("path");
const fs = require("fs");

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const PORT = process.env.PORT || 8080;
const MEDIA_DIR = path.resolve(process.env.MEDIA_DIR || "./media");

app.use(cors());
app.use(express.json());
fs.mkdirSync(MEDIA_DIR, { recursive: true });
app.use("/media", express.static(MEDIA_DIR));

async function init() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tracks (
      id SERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      artist TEXT NOT NULL,
      file_name TEXT NOT NULL,
      cover_url TEXT
    );
  `);
}
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Unauthorized" });
  }
}
function makeToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: "14d" });
}
app.post("/auth/register", async (req, res) => {
  try {
    const { email, password, displayName } = req.body || {};
    if (!email || !password || !displayName || password.length < 8)
      return res.status(400).json({ error: "Email, displayName and password (8+ chars) required" });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users(email,password_hash,display_name) VALUES($1,$2,$3) RETURNING id,email,display_name",
      [email.toLowerCase(), hash, displayName]
    );
    const user = result.rows[0];
    res.json({ token: makeToken(user), user: { id: String(user.id), email: user.email, displayName: user.display_name } });
  } catch (e) {
    res.status(400).json({ error: "Registration failed; email may already exist" });
  }
});
app.post("/auth/login", async (req, res) => {
  const { email, password } = req.body || {};
  const result = await pool.query("SELECT * FROM users WHERE email=$1", [(email || "").toLowerCase()]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password || "", user.password_hash)))
    return res.status(401).json({ error: "Invalid credentials" });
  res.json({ token: makeToken(user), user: { id: String(user.id), email: user.email, displayName: user.display_name } });
});
app.get("/me", auth, async (req, res) => {
  const result = await pool.query("SELECT id,email,display_name FROM users WHERE id=$1", [req.user.id]);
  const user = result.rows[0];
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ id: String(user.id), email: user.email, displayName: user.display_name });
});
app.get("/tracks", auth, async (_req, res) => {
  const result = await pool.query("SELECT id,title,artist,file_name,cover_url FROM tracks ORDER BY id DESC");
  res.json(result.rows.map(t => ({
    id: String(t.id), title: t.title, artist: t.artist, coverUrl: t.cover_url,
    streamUrl: `${process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`}/media/${encodeURIComponent(t.file_name)}`
  })));
});
app.listen(PORT, async () => {
  await init();
  console.log(`Qwenza API listening on ${PORT}`);
});
